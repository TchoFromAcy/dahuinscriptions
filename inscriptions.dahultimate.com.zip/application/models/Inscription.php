<?php
Class Default_Model_Inscription extends Default_Model_Model
{
	
	public $_tableName="Inscription";
	
} 