<?php
Class Default_Model_Tournoi extends Default_Model_Model
{
	
	public $_tableName="Tournoi";
	
} 