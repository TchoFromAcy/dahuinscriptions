<?php

class Default_Model_BtcalbumMapper extends Default_Model_Mapper {
	public $_tableName="Btcalbum";
	
		
	
}

?>