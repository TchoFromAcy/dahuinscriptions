<?php
/**
 * Classe de base des Table
 * @author Chau.T
 * @package Admin
 * @subpackage Model/DbTable
 * @version 1.0
 *
 */

class Default_Model_DbTable_Btcalbum extends Default_Model_DbTable_Table{

	/**
	 * 
	 * @var string $_name nom de la table
	 */
 	protected $_name="BTCalbum";
    /**
     * 
     * @var boolean $use_prefix true= ajouter DBPREFIX au nom de la table
     */
    protected $use_prefix=false;

    /**
     * 
     */
	

}