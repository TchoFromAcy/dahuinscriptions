<?php
Class Default_Model_Btcalbum extends Default_Model_Model
{
	
	public $_tableName="Btcalbum";
	
} 